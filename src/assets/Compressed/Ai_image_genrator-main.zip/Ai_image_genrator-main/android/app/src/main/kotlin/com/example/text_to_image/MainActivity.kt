package com.example.text_to_image

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
