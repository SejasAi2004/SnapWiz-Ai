export type ContentType =
  | "chats"
  | "presets"
  | "prompts"
  | "files"
  | "collections"
  | "assistants"
  | "tools"
  | "models"
